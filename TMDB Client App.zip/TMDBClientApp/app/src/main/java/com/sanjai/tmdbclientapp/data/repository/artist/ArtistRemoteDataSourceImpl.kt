package com.sanjai.tmdbclientapp.data.repository.artist

import com.sanjai.tmdbclientapp.data.api.TMDBService
import com.sanjai.tmdbclientapp.data.model.artist.ArtistList
import retrofit2.Response

class ArtistRemoteDataSourceImpl(private val tmdbService: TMDBService,
private val API_KEY : String) : ArtistRemoteDataSource {
    override suspend fun getAllArtist(): Response<ArtistList> {
        return tmdbService.getPopularArtist(API_KEY)
    }
}