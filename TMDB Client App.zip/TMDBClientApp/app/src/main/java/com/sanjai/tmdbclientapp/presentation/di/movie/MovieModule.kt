package com.sanjai.tmdbclientapp.presentation.di.movie

import com.sanjai.tmdbclientapp.domain.usecase.GetMoviesUseCase
import com.sanjai.tmdbclientapp.domain.usecase.UpdateMovieUseCase
import com.sanjai.tmdbclientapp.presentation.movie.MovieViewModelFactory
import dagger.Module
import dagger.Provides

@Module
class MovieModule {

    @MovieScope
    @Provides
    fun providerMovieViewModelFactory(
        getMoviesUseCase: GetMoviesUseCase,
        updateMovieUseCase: UpdateMovieUseCase
    ) : MovieViewModelFactory{
        return MovieViewModelFactory(getMoviesUseCase, updateMovieUseCase)
    }
}