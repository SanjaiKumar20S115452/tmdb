package com.sanjai.tmdbclientapp.presentation

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import com.sanjai.tmdbclientapp.R
import com.sanjai.tmdbclientapp.databinding.ActivityHomeBinding
import com.sanjai.tmdbclientapp.presentation.artist.ArtistActivity
import com.sanjai.tmdbclientapp.presentation.movie.MovieActivity
import com.sanjai.tmdbclientapp.presentation.tvshow.TvShowActivity

class HomeActivity : AppCompatActivity() {
    private lateinit var binding : ActivityHomeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_home)

        binding.apply {
            btnMovies.setOnClickListener {
                val intent = Intent(this@HomeActivity,MovieActivity::class.java)
                startActivity(intent)
            }
            btnArtist.setOnClickListener {
                val intent = Intent(this@HomeActivity,ArtistActivity::class.java)
                startActivity(intent)
            }
            btnTvShow.setOnClickListener {
                val intent = Intent(this@HomeActivity,TvShowActivity::class.java)
                startActivity(intent)
            }
        }
    }
}