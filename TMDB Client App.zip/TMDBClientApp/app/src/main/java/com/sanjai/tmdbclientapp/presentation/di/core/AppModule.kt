package com.sanjai.tmdbclientapp.presentation.di.core

import android.content.Context
import com.sanjai.tmdbclientapp.presentation.di.artist.ArtistSubComponent
import com.sanjai.tmdbclientapp.presentation.di.movie.MovieSubComponent
import com.sanjai.tmdbclientapp.presentation.di.tvshow.TvShowSubComponent
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module(subcomponents = [ArtistSubComponent::class,MovieSubComponent::class,TvShowSubComponent::class])
class AppModule(val context: Context) {

    @Singleton
    @Provides
    fun provideApplicationContext() : Context {
        return context.applicationContext
    }
}