package com.sanjai.tmdbclientapp.data.repository.tvshow.datasourceimpl

import com.sanjai.tmdbclientapp.data.api.TMDBService
import com.sanjai.tmdbclientapp.data.model.tvshow.TvShowList
import com.sanjai.tmdbclientapp.data.repository.tvshow.datasource.TvShowRemoteDataSource
import retrofit2.Response

class TvShowRemoteDataSourceImpl(private val tmdbService: TMDBService,
private val API_KEY : String) : TvShowRemoteDataSource {
    override suspend fun getTvShows(): Response<TvShowList> {
        return tmdbService.getPopularTvShows(API_KEY)
    }
}