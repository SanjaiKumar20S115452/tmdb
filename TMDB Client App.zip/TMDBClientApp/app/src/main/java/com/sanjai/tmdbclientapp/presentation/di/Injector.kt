package com.sanjai.tmdbclientapp.presentation.di

import com.sanjai.tmdbclientapp.presentation.di.artist.ArtistSubComponent
import com.sanjai.tmdbclientapp.presentation.di.movie.MovieSubComponent
import com.sanjai.tmdbclientapp.presentation.di.tvshow.TvShowSubComponent

interface Injector {
    fun createMovieSubComponent() : MovieSubComponent
    fun createTvShowSubComponent() : TvShowSubComponent
    fun createArtistSubComponent() : ArtistSubComponent
}