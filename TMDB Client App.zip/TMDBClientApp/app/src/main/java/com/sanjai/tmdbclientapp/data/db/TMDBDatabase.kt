package com.sanjai.tmdbclientapp.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.sanjai.tmdbclientapp.data.model.artist.Artist
import com.sanjai.tmdbclientapp.data.model.movie.Movie
import com.sanjai.tmdbclientapp.data.model.tvshow.TvShow

@Database(entities = [Movie::class,TvShow::class,Artist::class],
version = 1,exportSchema = false)
abstract class TMDBDatabase : RoomDatabase() {

    abstract fun movieDao() : MovieDAO
    abstract fun tvShowDao() : TvShowDAO
    abstract fun artistDao() : ArtistDAO
}