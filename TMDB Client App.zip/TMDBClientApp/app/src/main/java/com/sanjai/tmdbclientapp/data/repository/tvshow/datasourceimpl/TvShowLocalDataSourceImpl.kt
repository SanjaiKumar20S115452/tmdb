package com.sanjai.tmdbclientapp.data.repository.tvshow.datasourceimpl

import com.sanjai.tmdbclientapp.data.db.TvShowDAO
import com.sanjai.tmdbclientapp.data.model.tvshow.TvShow
import com.sanjai.tmdbclientapp.data.repository.tvshow.datasource.TvShowLocalDataSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TvShowLocalDataSourceImpl(private val tvShowDAO: TvShowDAO) : TvShowLocalDataSource {
    override suspend fun getTvShowsFromDB(): List<TvShow> {
        return tvShowDAO.getAllTvShow()
    }

    override suspend fun saveTvShowsToDB(tvShows: List<TvShow>) {
        CoroutineScope(Dispatchers.IO).launch {
            tvShowDAO.saveAllTvShows(tvShows)
        }
    }

    override suspend fun clearAll() {
        tvShowDAO.deleteAllTvShow()
    }
}