package com.sanjai.tmdbclientapp.presentation.di.core

import android.content.Context
import androidx.room.Room
import com.sanjai.tmdbclientapp.data.db.ArtistDAO
import com.sanjai.tmdbclientapp.data.db.MovieDAO
import com.sanjai.tmdbclientapp.data.db.TMDBDatabase
import com.sanjai.tmdbclientapp.data.db.TvShowDAO
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
class DatabaseModule {

    @Singleton
    @Provides
    fun provideDatabase(context: Context) : TMDBDatabase {
        return Room.databaseBuilder(
            context.applicationContext,
            TMDBDatabase::class.java,
            "tmdbClient"
        ).build()
    }

    @Singleton
    @Provides
    fun provideMovieDAO(tmdbDatabase: TMDBDatabase) : MovieDAO{
        return tmdbDatabase.movieDao()
    }

    fun provideTvDAO(tmdbDatabase: TMDBDatabase) : TvShowDAO {
        return tmdbDatabase.tvShowDao()
    }

    fun provideArtistDAO(tmdbDatabase: TMDBDatabase) : ArtistDAO {
        return tmdbDatabase.artistDao()
    }
}