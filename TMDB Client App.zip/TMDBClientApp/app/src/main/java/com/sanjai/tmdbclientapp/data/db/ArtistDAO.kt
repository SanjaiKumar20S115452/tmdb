package com.sanjai.tmdbclientapp.data.db

import androidx.room.*
import com.sanjai.tmdbclientapp.data.model.artist.Artist

@Dao
interface ArtistDAO {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveArtist(artist: List<Artist>)

    @Query("DELETE FROM popular_artists")
    suspend fun deleteAllArtist()

    @Query("SELECT * FROM popular_artists")
    suspend fun getAllArtist() : List<Artist>

}