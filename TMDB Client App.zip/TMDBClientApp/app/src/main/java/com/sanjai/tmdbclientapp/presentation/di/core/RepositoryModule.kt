package com.sanjai.tmdbclientapp.presentation.di.core

import com.sanjai.tmdbclientapp.data.repository.artist.ArtistCacheDataSource
import com.sanjai.tmdbclientapp.data.repository.artist.ArtistLocalDataSource
import com.sanjai.tmdbclientapp.data.repository.artist.ArtistRemoteDataSource
import com.sanjai.tmdbclientapp.data.repository.artist.ArtistRepositoryImpl
import com.sanjai.tmdbclientapp.data.repository.movies.datasource.MovieCacheDataSource
import com.sanjai.tmdbclientapp.data.repository.movies.datasource.MovieLocalDataSource
import com.sanjai.tmdbclientapp.data.repository.movies.datasource.MovieRemoteDataSource
import com.sanjai.tmdbclientapp.data.repository.movies.datasourceimpl.MovieRepositoryImpl
import com.sanjai.tmdbclientapp.data.repository.tvshow.datasource.TvShowCacheDataSource
import com.sanjai.tmdbclientapp.data.repository.tvshow.datasource.TvShowLocalDataSource
import com.sanjai.tmdbclientapp.data.repository.tvshow.datasource.TvShowRemoteDataSource
import com.sanjai.tmdbclientapp.data.repository.tvshow.datasourceimpl.TvShowRepositoryImpl
import com.sanjai.tmdbclientapp.domain.repository.ArtistRepository
import com.sanjai.tmdbclientapp.domain.repository.MovieRepository
import com.sanjai.tmdbclientapp.domain.repository.TvShowRepository
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
class RepositoryModule {

    @Singleton
    @Provides
    fun provideMovieRepository(
        movieRemoteDataSource: MovieRemoteDataSource,
        movieLocalDataSource: MovieLocalDataSource,
        movieCacheDataSource: MovieCacheDataSource
    ) : MovieRepository{
        return MovieRepositoryImpl(
            movieRemoteDataSource,
            movieCacheDataSource, movieLocalDataSource
        )
    }

    @Singleton
    @Provides
    fun provideTvShowRepository(
        tvShowRemoteDataSource: TvShowRemoteDataSource,
        tvShowLocalDataSource: TvShowLocalDataSource,
        tvShowCacheDataSource: TvShowCacheDataSource
    ) : TvShowRepository{
        return TvShowRepositoryImpl(
            tvShowRemoteDataSource, tvShowLocalDataSource, tvShowCacheDataSource
        )
    }

    @Singleton
    @Provides
    fun provideArtistRepository(
        artistRemoteDataSource: ArtistRemoteDataSource,
        artistLocalDataSource: ArtistLocalDataSource,
        artistCacheDataSource: ArtistCacheDataSource
    ) : ArtistRepository{
        return ArtistRepositoryImpl(
            artistRemoteDataSource,
            artistLocalDataSource,
            artistCacheDataSource
        )
    }
}