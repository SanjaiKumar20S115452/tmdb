package com.sanjai.tmdbclientapp.domain.repository

import androidx.core.widget.TintableImageSourceView
import com.sanjai.tmdbclientapp.data.model.tvshow.TvShow

interface TvShowRepository {
    suspend fun getTvShow() : List<TvShow>?
    suspend fun updateTvShow() : List<TvShow>?
}