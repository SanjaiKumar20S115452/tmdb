package com.sanjai.tmdbclientapp.data.repository.movies.datasource

import androidx.constraintlayout.utils.widget.MockView
import com.sanjai.tmdbclientapp.data.model.movie.Movie

interface MovieLocalDataSource {
    suspend fun getMoviesFromDB() : List<Movie>
    suspend fun saveMoviesToDB(movies : List<Movie>)
    suspend fun clearAll()
}