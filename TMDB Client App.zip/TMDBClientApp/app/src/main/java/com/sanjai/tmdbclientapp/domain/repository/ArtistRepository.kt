package com.sanjai.tmdbclientapp.domain.repository

import com.sanjai.tmdbclientapp.data.model.artist.Artist

interface ArtistRepository {
    suspend fun getArtist() : List<Artist>?
    suspend fun updateArtist() : List<Artist>?
}