package com.sanjai.tmdbclientapp.data.repository.tvshow.datasource

import com.sanjai.tmdbclientapp.data.model.tvshow.TvShow

interface TvShowCacheDataSource {
    suspend fun getTvShowsFromCache() : List<TvShow>
    suspend fun saveTvShowToCache(tvShows : List<TvShow>)
}