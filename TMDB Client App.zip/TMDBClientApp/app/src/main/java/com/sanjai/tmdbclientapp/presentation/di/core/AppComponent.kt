package com.sanjai.tmdbclientapp.presentation.di.core

import com.sanjai.tmdbclientapp.presentation.di.artist.ArtistSubComponent
import com.sanjai.tmdbclientapp.presentation.di.movie.MovieSubComponent
import com.sanjai.tmdbclientapp.presentation.di.tvshow.TvShowSubComponent
import dagger.Component
import dagger.Module
import javax.inject.Singleton

@Singleton
@Component(modules =
[AppModule::class,
NetModule::class,
DatabaseModule::class,
RepositoryModule::class,
RemoteDataModule::class,
LocalDataModule::class,
CacheDataModule::class,
UseCaseModule::class
])
public abstract interface AppComponent {
    fun movieSubComponent() : MovieSubComponent.Factory
    fun tvShowSubComponent() : TvShowSubComponent.Factory
    fun artistSubComponent() : ArtistSubComponent.Factory
}