package com.sanjai.tmdbclientapp.data.repository.movies.datasourceimpl

import com.sanjai.tmdbclientapp.data.model.movie.Movie
import com.sanjai.tmdbclientapp.data.repository.movies.datasource.MovieCacheDataSource

class MovieCacheDataSourceImpl : MovieCacheDataSource {
    private var movieList = ArrayList<Movie>()
    override suspend fun getMoviesFromCache(): List<Movie> {
        return movieList
    }

    override suspend fun saveMoviesToCache(movies: List<Movie>) {
        movieList.clear()
        movieList = ArrayList(movies)
    }
}