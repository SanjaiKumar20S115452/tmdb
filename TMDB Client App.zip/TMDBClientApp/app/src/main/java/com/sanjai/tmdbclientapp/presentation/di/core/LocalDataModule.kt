package com.sanjai.tmdbclientapp.presentation.di.core

import com.sanjai.tmdbclientapp.data.db.ArtistDAO
import com.sanjai.tmdbclientapp.data.db.MovieDAO
import com.sanjai.tmdbclientapp.data.db.TvShowDAO
import com.sanjai.tmdbclientapp.data.repository.artist.ArtistLocalDataSource
import com.sanjai.tmdbclientapp.data.repository.artist.ArtistLocalDataSourceImpl
import com.sanjai.tmdbclientapp.data.repository.movies.datasource.MovieLocalDataSource
import com.sanjai.tmdbclientapp.data.repository.movies.datasourceimpl.MovieLocalDataSourceImpl
import com.sanjai.tmdbclientapp.data.repository.tvshow.datasource.TvShowLocalDataSource
import com.sanjai.tmdbclientapp.data.repository.tvshow.datasourceimpl.TvShowLocalDataSourceImpl
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
class LocalDataModule {

    @Singleton
    @Provides
    fun provideMovieLocalDataSource(movieDAO: MovieDAO) : MovieLocalDataSource {
        return MovieLocalDataSourceImpl(movieDAO)
    }

    @Singleton
    @Provides
    fun provideTvShowLocalDataSource(tvShowDAO: TvShowDAO) : TvShowLocalDataSource {
        return TvShowLocalDataSourceImpl(tvShowDAO)
    }

    @Singleton
    @Provides
    fun provideArtistLocalDataSource(artistDAO: ArtistDAO) : ArtistLocalDataSource {
        return ArtistLocalDataSourceImpl(artistDAO)
    }
}