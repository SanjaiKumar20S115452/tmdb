package com.sanjai.tmdbclientapp.domain.usecase

import com.sanjai.tmdbclientapp.data.model.movie.Movie
import com.sanjai.tmdbclientapp.domain.repository.MovieRepository

class GetMoviesUseCase(private val movieRepository: MovieRepository) {
    suspend fun execute() : List<Movie>? = movieRepository.getMovies()
}