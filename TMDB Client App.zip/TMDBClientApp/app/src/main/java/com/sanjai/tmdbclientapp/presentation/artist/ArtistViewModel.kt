package com.sanjai.tmdbclientapp.presentation.artist

import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.sanjai.tmdbclientapp.domain.usecase.GetArtistUseCase
import com.sanjai.tmdbclientapp.domain.usecase.UpdateArtistUseCase

class ArtistViewModel(
    private val getArtistUseCase: GetArtistUseCase,
    private val updateArtistUseCase: UpdateArtistUseCase
) : ViewModel() {

    fun getArtists() = liveData {
        val artistTvList = getArtistUseCase.execute()
        emit(artistTvList)
    }

    fun updateArtist() = liveData {
        val artistListItem = updateArtistUseCase.execute()
        emit(artistListItem)
    }
}