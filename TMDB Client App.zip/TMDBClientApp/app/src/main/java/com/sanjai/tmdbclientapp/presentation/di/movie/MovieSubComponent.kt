package com.sanjai.tmdbclientapp.presentation.di.movie

import com.sanjai.tmdbclientapp.presentation.di.artist.ArtistScope
import com.sanjai.tmdbclientapp.presentation.movie.MovieActivity
import dagger.Subcomponent

@MovieScope
@Subcomponent(modules = [MovieModule::class])
interface MovieSubComponent {
    fun inject(movieActivity: MovieActivity)

    @Subcomponent.Factory
    interface Factory {
        fun create() : MovieSubComponent
    }
}