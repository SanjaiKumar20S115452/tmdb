package com.sanjai.tmdbclientapp.domain.repository

import com.sanjai.tmdbclientapp.data.model.movie.Movie

interface MovieRepository {
    suspend fun getMovies() : List<Movie>?
    suspend fun updateMovies() : List<Movie>?
}