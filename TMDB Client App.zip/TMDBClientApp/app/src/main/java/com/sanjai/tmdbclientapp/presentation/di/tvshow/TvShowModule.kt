package com.sanjai.tmdbclientapp.presentation.di.tvshow

import com.sanjai.tmdbclientapp.domain.usecase.GetTvShowUseCase
import com.sanjai.tmdbclientapp.domain.usecase.UpdateTvShowUseCase
import com.sanjai.tmdbclientapp.presentation.tvshow.TvShowViewModelFactory
import dagger.Module
import dagger.Provides

@Module
class TvShowModule {

    @TvShowScope
    @Provides
    fun providerTvShowViewModelFactory(
        getTvShowUseCase: GetTvShowUseCase,
        updateTvShowUseCase: UpdateTvShowUseCase
    ) : TvShowViewModelFactory {
        return TvShowViewModelFactory(getTvShowUseCase, updateTvShowUseCase)
    }
}