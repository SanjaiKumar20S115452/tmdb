package com.sanjai.tmdbclientapp.presentation.di.core

import com.sanjai.tmdbclientapp.data.repository.artist.ArtistCacheDataSource
import com.sanjai.tmdbclientapp.data.repository.artist.ArtistCacheDataSourceImpl
import com.sanjai.tmdbclientapp.data.repository.movies.datasource.MovieCacheDataSource
import com.sanjai.tmdbclientapp.data.repository.movies.datasourceimpl.MovieCacheDataSourceImpl
import com.sanjai.tmdbclientapp.data.repository.tvshow.datasource.TvShowCacheDataSource
import com.sanjai.tmdbclientapp.data.repository.tvshow.datasourceimpl.TvShowCacheDataSourceImpl
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
class CacheDataModule {

    @Singleton
    @Provides
    fun provideMoviesCacheDataSource() : MovieCacheDataSource {
        return MovieCacheDataSourceImpl()
    }

    @Singleton
    @Provides
    fun provideTvShowCacheDataSource() : TvShowCacheDataSource {
        return TvShowCacheDataSourceImpl()
    }

    @Singleton
    @Provides
    fun provideArtistCacheSource() : ArtistCacheDataSource {
        return ArtistCacheDataSourceImpl()
    }
}