package com.sanjai.tmdbclientapp.data.repository.artist

import com.sanjai.tmdbclientapp.data.model.artist.ArtistList
import retrofit2.Response

interface ArtistRemoteDataSource {
    suspend fun getAllArtist() : Response<ArtistList>
}