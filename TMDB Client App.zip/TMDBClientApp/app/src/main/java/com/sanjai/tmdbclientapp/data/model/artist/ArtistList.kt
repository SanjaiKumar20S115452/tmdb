package com.sanjai.tmdbclientapp.data.model.artist


import com.google.gson.annotations.SerializedName
import com.sanjai.tmdbclientapp.data.model.artist.Artist

data class ArtistList(
    @SerializedName("results")
    val artists: List<Artist>
)