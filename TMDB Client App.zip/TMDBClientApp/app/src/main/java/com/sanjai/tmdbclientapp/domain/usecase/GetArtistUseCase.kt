package com.sanjai.tmdbclientapp.domain.usecase

import com.sanjai.tmdbclientapp.data.model.artist.Artist
import com.sanjai.tmdbclientapp.domain.repository.ArtistRepository

class GetArtistUseCase(private val artistRepository: ArtistRepository) {
    suspend fun execute() : List<Artist>? = artistRepository.getArtist()
}