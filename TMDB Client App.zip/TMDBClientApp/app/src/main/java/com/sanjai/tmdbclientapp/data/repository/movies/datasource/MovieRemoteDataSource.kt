package com.sanjai.tmdbclientapp.data.repository.movies.datasource

import com.sanjai.tmdbclientapp.data.model.movie.MovieList
import retrofit2.Response

interface MovieRemoteDataSource {

    suspend fun getMovies() : Response<MovieList>
}