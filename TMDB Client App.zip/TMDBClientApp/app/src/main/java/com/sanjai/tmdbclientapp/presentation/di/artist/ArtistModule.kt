package com.sanjai.tmdbclientapp.presentation.di.artist

import com.sanjai.tmdbclientapp.domain.usecase.GetArtistUseCase
import com.sanjai.tmdbclientapp.domain.usecase.UpdateArtistUseCase
import com.sanjai.tmdbclientapp.presentation.artist.ArtistViewModelFactory
import dagger.Module
import dagger.Provides

@Module
class ArtistModule {

    @ArtistScope
    @Provides
    fun providerArtistViewModelFactory(getArtistUseCase: GetArtistUseCase,
    updateArtistUseCase: UpdateArtistUseCase) : ArtistViewModelFactory {
        return ArtistViewModelFactory(getArtistUseCase, updateArtistUseCase)
    }
}