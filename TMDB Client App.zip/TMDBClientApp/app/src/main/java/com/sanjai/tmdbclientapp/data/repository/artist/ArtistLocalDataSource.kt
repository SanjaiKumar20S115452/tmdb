package com.sanjai.tmdbclientapp.data.repository.artist

import com.sanjai.tmdbclientapp.data.model.artist.Artist

interface ArtistLocalDataSource {
    suspend fun getArtistFromDB() : List<Artist>
    suspend fun saveArtistToDB(artist : List<Artist>)
    suspend fun clearAll()
}