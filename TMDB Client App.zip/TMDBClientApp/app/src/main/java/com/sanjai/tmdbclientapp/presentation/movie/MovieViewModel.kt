package com.sanjai.tmdbclientapp.presentation.movie

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.sanjai.tmdbclientapp.domain.usecase.GetMoviesUseCase
import com.sanjai.tmdbclientapp.domain.usecase.UpdateMovieUseCase

class MovieViewModel(
    private val getMoviesUseCase: GetMoviesUseCase,
    private val updateMovieUseCase: UpdateMovieUseCase
) : ViewModel() {

    fun getMovies() = liveData {
        val movieList = getMoviesUseCase.execute()
        emit(movieList)
    }

    fun updateMovies() = liveData {
        val moviesList = updateMovieUseCase.execute()
        emit(moviesList)
    }
}