package com.sanjai.tmdbclientapp.data.repository.artist

import com.sanjai.tmdbclientapp.data.model.artist.Artist

class ArtistCacheDataSourceImpl : ArtistCacheDataSource {
    private var artistListItem = ArrayList<Artist>()
    override suspend fun getArtistFromCache(): List<Artist> {
        return artistListItem
    }

    override suspend fun saveArtistToCache(artist: List<Artist>) {
        artistListItem.clear()
        artistListItem = ArrayList(artist)
    }
}