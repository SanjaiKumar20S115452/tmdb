package com.sanjai.tmdbclientapp.presentation.di.tvshow

import javax.inject.Scope

@Scope
@kotlin.annotation.Retention(AnnotationRetention.RUNTIME)
annotation class TvShowScope