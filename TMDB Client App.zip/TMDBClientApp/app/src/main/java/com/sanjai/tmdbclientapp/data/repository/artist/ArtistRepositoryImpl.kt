package com.sanjai.tmdbclientapp.data.repository.artist

import android.util.Log
import com.sanjai.tmdbclientapp.data.model.artist.Artist
import com.sanjai.tmdbclientapp.domain.repository.ArtistRepository
import java.lang.Exception

class ArtistRepositoryImpl(
    private val artistRemoteDataSource: ArtistRemoteDataSource,
    private val artistLocalDataSource: ArtistLocalDataSource,
    private val artistCacheDataSource: ArtistCacheDataSource
) : ArtistRepository {
    override suspend fun getArtist(): List<Artist>? {
        return getArtistFromCache()
    }

    override suspend fun updateArtist(): List<Artist>? {
        val newListFromAPI = getArtistFromAPI()
        artistLocalDataSource.clearAll()
        artistLocalDataSource.saveArtistToDB(newListFromAPI)
        artistCacheDataSource.saveArtistToCache(newListFromAPI)
        return newListFromAPI
    }

    suspend fun getArtistFromAPI() : List<Artist> {
        lateinit var artistList : List<Artist>
        try {
            val response = artistRemoteDataSource.getAllArtist()
            val body = response.body()
            if(body != null) {
                artistList = body.artists
            }
        }catch (exception:Exception) {
            Log.i("mytag",exception.message.toString())
        }
        return artistList
    }

    suspend fun getArtistFromDB() : List<Artist> {
        lateinit var artistListItem : List<Artist>
        try {
            artistLocalDataSource.getArtistFromDB()
        }catch (exception:Exception) {
            Log.i("mytag",exception.message.toString())
        }
        if(artistListItem.size > 0) {
            return artistListItem
        }else {
            artistListItem = getArtistFromAPI()
            artistLocalDataSource.saveArtistToDB(artistListItem)
        }
        return artistListItem
    }

    suspend fun getArtistFromCache() : List<Artist> {
        lateinit var artistListItem : List<Artist>
        try {
            artistCacheDataSource.getArtistFromCache()
        }catch (exception:Exception) {
            Log.i("mytag",exception.message.toString())
        }
        if(artistListItem.size > 0) {
            return artistListItem
        }else {
            artistListItem = getArtistFromDB()
            artistCacheDataSource.saveArtistToCache(artistListItem)
        }
        return artistListItem
    }
}