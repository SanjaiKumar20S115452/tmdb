package com.sanjai.tmdbclientapp.data.repository.tvshow.datasourceimpl

import android.util.Log
import com.sanjai.tmdbclientapp.data.model.tvshow.TvShow
import com.sanjai.tmdbclientapp.data.repository.tvshow.datasource.TvShowCacheDataSource
import com.sanjai.tmdbclientapp.data.repository.tvshow.datasource.TvShowLocalDataSource
import com.sanjai.tmdbclientapp.data.repository.tvshow.datasource.TvShowRemoteDataSource
import com.sanjai.tmdbclientapp.domain.repository.TvShowRepository
import java.lang.Exception

class TvShowRepositoryImpl(
    val tvShowRemoteDataSource: TvShowRemoteDataSource,
    val tvShowLocalDataSource: TvShowLocalDataSource,
    val tvShowCacheDataSource: TvShowCacheDataSource
) : TvShowRepository {
    override suspend fun getTvShow(): List<TvShow>? {
        return getTvShowsFromCache()
    }

    override suspend fun updateTvShow(): List<TvShow>? {
        val newListFromAPI = getTvShowsFromAPI()
        tvShowLocalDataSource.clearAll()
        tvShowCacheDataSource.saveTvShowToCache(newListFromAPI)
        tvShowLocalDataSource.saveTvShowsToDB(newListFromAPI)
        return newListFromAPI
    }

    suspend fun getTvShowsFromAPI() : List<TvShow> {
        lateinit var tvShowList : List<TvShow>
        try {
            val response = tvShowRemoteDataSource.getTvShows()
            val body = response.body()
            if(body != null) {
                tvShowList = body.tvShows
            }
        }catch (exception: Exception) {
            Log.i("mytag",exception.message.toString())
        }
        return tvShowList
    }

    suspend fun getTvShowsFromDB() : List<TvShow> {
        lateinit var tvShowList : List<TvShow>
        try {
            tvShowLocalDataSource.getTvShowsFromDB()
        }catch (exception:Exception) {
            Log.i("mytag",exception.message.toString())
        }
        if(tvShowList.size > 0) {
            return tvShowList
        }else {
            tvShowList = getTvShowsFromAPI()
            tvShowLocalDataSource.saveTvShowsToDB(tvShowList)
        }
        return tvShowList
    }

    suspend fun getTvShowsFromCache() : List<TvShow> {
        lateinit var tvShowList : List<TvShow>
        try {
            tvShowCacheDataSource.getTvShowsFromCache()
        }catch (exception:Exception) {
            Log.i("mytag",exception.message.toString())
        }
        if(tvShowList.size > 0) {
            return tvShowList
        }else {
            tvShowList = getTvShowsFromDB()
            tvShowCacheDataSource.saveTvShowToCache(tvShowList)
        }
        return tvShowList
    }
}