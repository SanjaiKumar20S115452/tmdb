package com.sanjai.tmdbclientapp.data.repository.movies.datasourceimpl

import com.sanjai.tmdbclientapp.data.api.TMDBService
import com.sanjai.tmdbclientapp.data.model.movie.MovieList
import com.sanjai.tmdbclientapp.data.repository.movies.datasource.MovieRemoteDataSource
import retrofit2.Response

class MovieRemoteDataSourceImpl(private val tmdbService: TMDBService,
private val apiKey : String) : MovieRemoteDataSource {
    override suspend fun getMovies(): Response<MovieList> {
        return tmdbService.getPopularMovies(apiKey)
    }
}