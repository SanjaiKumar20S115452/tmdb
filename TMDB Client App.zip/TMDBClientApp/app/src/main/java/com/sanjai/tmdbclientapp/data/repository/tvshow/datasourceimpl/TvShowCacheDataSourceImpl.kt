package com.sanjai.tmdbclientapp.data.repository.tvshow.datasourceimpl

import com.sanjai.tmdbclientapp.data.model.tvshow.TvShow
import com.sanjai.tmdbclientapp.data.repository.tvshow.datasource.TvShowCacheDataSource

class TvShowCacheDataSourceImpl : TvShowCacheDataSource {
    private var tvShowList = ArrayList<TvShow>()
    override suspend fun getTvShowsFromCache(): List<TvShow> {
        return tvShowList
    }

    override suspend fun saveTvShowToCache(tvShows: List<TvShow>) {
        tvShowList.clear()
        tvShowList = ArrayList(tvShows)
    }
}