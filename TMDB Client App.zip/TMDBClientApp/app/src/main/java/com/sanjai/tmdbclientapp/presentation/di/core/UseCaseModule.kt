package com.sanjai.tmdbclientapp.presentation.di.core

import com.sanjai.tmdbclientapp.domain.repository.ArtistRepository
import com.sanjai.tmdbclientapp.domain.repository.MovieRepository
import com.sanjai.tmdbclientapp.domain.repository.TvShowRepository
import com.sanjai.tmdbclientapp.domain.usecase.*
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
class UseCaseModule {

    @Singleton
    @Provides
    fun provideMovieUseCase(movieRepository: MovieRepository) : GetMoviesUseCase {
        return GetMoviesUseCase(movieRepository)
    }

    @Singleton
    @Provides
    fun provideUpdateMovieUseCase(movieRepository: MovieRepository) : UpdateMovieUseCase {
        return UpdateMovieUseCase(movieRepository)
    }

    @Singleton
    @Provides
    fun provideTvShowUseCase(tvShowRepository: TvShowRepository) : GetTvShowUseCase {
        return GetTvShowUseCase(tvShowRepository)
    }

    @Singleton
    @Provides
    fun provideTvShowUpdateUseCase(tvShowRepository: TvShowRepository) : UpdateTvShowUseCase {
        return UpdateTvShowUseCase(tvShowRepository)
    }

    @Singleton
    @Provides
    fun provideArtistUseCase(artistRepository: ArtistRepository) : GetArtistUseCase {
        return GetArtistUseCase(artistRepository)
    }

    @Singleton
    @Provides
    fun updateArtistUseCase(artistRepository: ArtistRepository) : UpdateArtistUseCase {
        return UpdateArtistUseCase(artistRepository)
    }
}