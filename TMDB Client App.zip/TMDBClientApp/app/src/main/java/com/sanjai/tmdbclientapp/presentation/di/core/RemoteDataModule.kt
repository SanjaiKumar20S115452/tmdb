package com.sanjai.tmdbclientapp.presentation.di.core

import com.sanjai.tmdbclientapp.data.api.TMDBService
import com.sanjai.tmdbclientapp.data.repository.artist.ArtistRemoteDataSource
import com.sanjai.tmdbclientapp.data.repository.artist.ArtistRemoteDataSourceImpl
import com.sanjai.tmdbclientapp.data.repository.movies.datasource.MovieRemoteDataSource
import com.sanjai.tmdbclientapp.data.repository.movies.datasourceimpl.MovieRemoteDataSourceImpl
import com.sanjai.tmdbclientapp.data.repository.tvshow.datasource.TvShowRemoteDataSource
import com.sanjai.tmdbclientapp.data.repository.tvshow.datasourceimpl.TvShowRemoteDataSourceImpl
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
class RemoteDataModule(private val api_key : String) {

    @Singleton
    @Provides
    fun provideMovieRemoteDataSource(tmdbService: TMDBService) : MovieRemoteDataSource {
        return MovieRemoteDataSourceImpl(tmdbService,api_key)
    }

    @Singleton
    @Provides
    fun provideTvShowRemoteDataSource(tmdbService: TMDBService) : TvShowRemoteDataSource {
        return TvShowRemoteDataSourceImpl(tmdbService,api_key)
    }

    @Singleton
    @Provides
    fun provideArtistRemoteDataSource(tmdbService: TMDBService) : ArtistRemoteDataSource {
        return ArtistRemoteDataSourceImpl(tmdbService,api_key)
    }
 }