package com.sanjai.tmdbclientapp.data.repository.tvshow.datasource

import com.sanjai.tmdbclientapp.data.model.tvshow.TvShow

interface TvShowLocalDataSource {
    suspend fun getTvShowsFromDB() : List<TvShow>
    suspend fun saveTvShowsToDB(tvShows : List<TvShow>)
    suspend fun clearAll()
}