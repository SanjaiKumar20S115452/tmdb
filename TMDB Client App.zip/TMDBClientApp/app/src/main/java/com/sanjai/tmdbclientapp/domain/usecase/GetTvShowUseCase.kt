package com.sanjai.tmdbclientapp.domain.usecase

import com.sanjai.tmdbclientapp.data.model.tvshow.TvShow
import com.sanjai.tmdbclientapp.domain.repository.TvShowRepository

class GetTvShowUseCase(private val tvShowRepository: TvShowRepository) {
    suspend fun execute() : List<TvShow>? = tvShowRepository.getTvShow()
}